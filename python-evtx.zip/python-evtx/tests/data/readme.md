The source for system.evtx with md5 182de19fe6a25b928a34ad59af0bbf1e
 was https://github.com/log2timeline/plaso/tree/1e2fa282efa2f839e1f179a3e98dbf922b5dbbc7/test_data

The source for security.evtx with md5 8fa20a376cb6745453bc51f906e0fcd0
 was Carlos Dias, via email, on May 4, 2017.

The source for ae831beda7dfda43f4de0e18a1035f64/dns_log_malformed.evtx
 was @stephensheridan, via Github issue #37 (https://github.com/williballenthin/python-evtx/issues/37).

The source for d75c90e629f38c7b9e612905e02e2255  issue_38.evtx
 was @nbareil, via Github issue #38 (https://github.com/williballenthin/python-evtx/issues/38).

